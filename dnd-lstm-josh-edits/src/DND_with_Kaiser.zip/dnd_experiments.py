from cProfile import run
from cmath import log
from contextual_choice import run_experiment
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

def get_sim_threshhold(exp_type, kernel = "cosine", context = "no_context"):
    # Manually found over some data 
    # HIGHLY TWEAKABLE
    if exp_type == "Original":
        if kernel == "l2":
            if context == "full":
                return -9.5
            elif context == 'no_context':
                return -7
        elif kernel == 'cosine':
            if context == "full":
                return 0.05
            elif context == 'no_context':
                return 0.1
    elif exp_type == "Quarter":
        if kernel == "l2":
            if context == "full":
                return -1.2
            elif context == 'no_context':
                return -0.8
        elif kernel == 'cosine':
            if context == "full":
                return 0.4
            elif context == 'no_context':
                return 0.45
    else:
        raise ValueError(f'unrecog exp_type: {exp_type} or unrecog kernel: {kernel}')

def graph_the_things(epochs, exp_type, num_repeats = 1, sim_thresh = False, kernel = [], update = [], change_task = [], noise = []):
    """
    run experiments function is wonky, so how to specialize it to make these changes easier
    """
    log_return = [[]]
    log_sims = [[]]
    for num1 in range(len(exp_type)):
        len_input2 = max(len(kernel), len(update), len(change_task), len(noise))
        for num2 in range(len_input2):
            runs = []
            sims = []
            change = [exp_type[num1], 'no_context']
            context = 'no_context'
            kernel1 = 'cosine'
            
            # Only use memory update on our version
            if change[0] == 'Quarter':
                change.append('update_avg')
            if kernel:
                kernel1 = kernel[num2]
            elif update:
                updates = update[num2]
                change.append(updates)
            elif change_task:
                context = change_task[num2]
                change.append(context)
            elif noise:
                change.append(('noise', noise[num2]))
            if sim_thresh and change[0] == 'Quarter':
                sim_threshhold = get_sim_threshhold(exp_type = 'Quarter', kernel = kernel1, context = context)
            else:
                if kernel1 == 'cosine':
                    sim_threshhold = -20
                elif kernel1 == 'l2':
                    sim_threshhold = -200
            for iter in range(num_repeats):
                print("- -"*10)
                print('Iteration:', iter, change, kernel1)
                returns, loss, avg_sim = run_experiment(epochs, sim_threshhold, 
                                                            change = change,
                                                            kernel = kernel1)
                runs.append(returns)
                sims.append(avg_sim)
            avg_returns = np.mean(runs, axis = 0)                                     
            avg_sims = np.mean(sims, axis = 0)                                     
            log_return[num1].append((avg_returns, change))        
            log_sims[num1].append((avg_sims, change))        
        log_return.append([])
        log_sims.append([])
    return log_return, log_sims



epochs = 20
num_repeats = 20
exp_type = ["Original", "Quarter"]
kernel = ['cosine', 'l2']
noise = [0.5, 0.75, 0.85, 0.9]
update_type = ['no', 'update_avg', 'update_ind_avg']
change_task = ['full', 'no_context']

log_returns = []
# log_returns.append(graph_the_things(epochs, exp_type, num_repeats, sim_thresh = True, change_task=change_task))
# log_returns.append(graph_the_things(epochs, exp_type, num_repeats, sim_thresh = False, change_task=change_task))
# log_returns.append(graph_the_things(epochs, exp_type, kernel=kernel))
# log_returns.append(graph_the_things(epochs, exp_type, num_repeats, sim_thresh = True, update=update_type))
# log_returns.append(graph_the_things(epochs, exp_type, num_repeats, sim_thresh = False, update=update_type))
log_returns, log_sims = graph_the_things(epochs, exp_type, num_repeats, sim_thresh = True, noise=noise)
# print(log_returns)

f, axes = plt.subplots(1, 2, figsize=(16, 10))
dataz = []
labelz= []
for ind_trial in range(len(log_returns)):
    for exp in range(len(log_returns[ind_trial])):
        # Returns
        data = log_returns[ind_trial][exp][0]
        exp_type = log_returns[ind_trial][exp][1][0]
        label = (exp_type,log_returns[ind_trial][exp][1][-1][1])
        if exp_type == 'Original':
            linestyle = 'dashed'
            marker = 'o'
        if exp_type == 'Quarter':
            linestyle = 'solid'
            marker = 'x'
        axes[0].plot(data, linestyle=linestyle, marker=marker, label = label)

        # Avg Similarity
        dataz.append(log_sims[ind_trial][exp][0])
        labelz.append((log_sims[ind_trial][exp][1][0],log_sims[ind_trial][exp][1][-1][1]))

axes[0].set_ylabel('Return')
axes[0].set_xlabel('Epoch')
axes[0].legend(bbox_to_anchor=(0,-0.4,1,0.2), loc="lower left",
                mode="expand", borderaxespad=0, ncol=2)
axes[1].plot(dataz, 'bo')
axes[1].set_ylabel('Average Similiarity')
plt.subplot(122)
plt.xticks(range(len(labelz)), labelz, rotation = 45)

sns.despine()
f.tight_layout()
f.subplots_adjust(top=0.9)
plt.suptitle("Kernel: Cosine, Dict Len: 100, Input Dim: 128, Trial Length: 10 \n Sim Thresholding, Memory Updates on Quarter Trials Only", y=.98)
plt.show()